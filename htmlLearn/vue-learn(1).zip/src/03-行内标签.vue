<template>
  <div>
    <del>你好</del>
    <hr>
    2 <sup>3</sup>
  </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>