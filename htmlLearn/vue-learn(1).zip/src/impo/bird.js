export default 3.14;

export var legs = 2;