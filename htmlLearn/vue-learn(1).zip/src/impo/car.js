export var name = "奥迪";
export var age = 1.5;

export function run(){
    console.log("speed = 170km/h");
}

export const say=()=>{
    console.log("滴滴滴");
}



