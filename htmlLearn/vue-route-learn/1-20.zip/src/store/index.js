import { createStore } from 'vuex'

export default createStore({
  state: {
    collapse:false,
  },
   //修改，同步修改
  mutations: {
    
  },
    //修改，异步修改
  actions: {
   
  },
  getters: {
  }
})